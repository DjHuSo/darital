module.exports = {
    TOKEN:'7060721197:AAFS_wUuQW6YLA99aksJ78QiySaNyr8Jqlo'
}