// var XLSX = require ("xlsx");

// var workbook = XLSX.readFile("123.xlsx");
// let worksheet = workbook.Sheets[workbook.SheetNames[0]];

// for (let cell in worksheet) {
//     const value = worksheet[cell].v;
//     if(value) {
//         console.log(value);
//     }
// }
const express = require('express')
const mongoose = require('mongoose')
const app = express()
require('dotenv').config()
app.use(express.json())

async function dev() {
  try {
    await mongoose.connect(process.env.MONGO_URL,{
      useNewUrlParser: true
    }).then(()=> {console.log('Mongo Start')})
    .catch((error)=>{confirm.log(error)})
    app.listen(process.env.PORT,()=> {console.log('Server Connect')})

   } catch (error) {
    console.log(error)
  }
}



var xlsx = require("xlsx");
var wb = xlsx.readFile("files/123.xlsx", { cellDates: true });
var ws = wb.Sheets["elektr"];

const TelegramBot = require('node-telegram-bot-api');

const TOKEN = process.env.TOKEN
const bot = new TelegramBot(TOKEN, {
   polling:{
    interval:300,
    autoStart:true,
    params:{
      timeout:10
    }
   }
})

bot.onText(/\/start/, msg =>{
  const text = `Assalomu aleykum ${msg.from.first_name} \nSiz /start tugmasini bosdingiz!`
  bot.sendMessage(msg.chat.id , text)
});
bot.on('message',  (msg) => {
    let data = 4; 
  //  let gaz1 = 5; 
   let sum = 16;
   let sumo = 17;
   let tr1 = 7;
   let ekstra = 8;
   let press = 9;
   let tr2 = 11;
   let raf = 12;
   let gea = 13;
   let qadoq = 14;
   ///////
   let tr1kw = 7;
   let ekstrakw = 8;
   let presskw = 9;
   let tr2kw = 11;
   let rafkw = 12;
   let geakw = 13;
   let qadoqkw = 14;
   ///////////////
   let tr1sum = 7;
   let ekstrasum = 8;
   let presssum = 9;
   let tr2sum = 11;
   let rafsum = 12;
   let geasum = 13;
   let qadoqsum = 14;
   let i = 0

 do {
   // var uz = ws["B4"];
   // var uz1 = ws["B1176"];
   //var data = xlsx.utils.sheet_to_json(ws);
   ////// nomi
   let num = 14;
   let num2 = 1;
   data += 14;
  // gaz1 = num2 + gaz1
   sum = num + sum;
   sumo = num + sumo;
   tr1 = num + tr1;
   ekstra = num + ekstra;
   press = num + press;
   tr2 = num + tr2;
   raf = num + raf;
   gea = num + gea;
   qadoq = num + qadoq;
   //////////// kw da
   tr1kw = num + tr1kw;
   ekstrakw = num + ekstrakw;
   presskw = num + presskw;
   tr2kw = num + tr2kw;
   rafkw = num + rafkw;
   geakw = num + geakw;
   qadoqkw = num + qadoqkw;
   /////////////  so'mda 
   tr1sum = num + tr1sum;
   ekstrasum = num + ekstrasum;
   presssum = num + presssum;
   tr2sum = num + tr2sum;
   rafsum = num + rafsum;
   geasum = num + geasum;
   qadoqsum = num + qadoqsum;
   
   //var uzz = ws[`B4`].w;
   var uz = ws[`B${data}`].w; ////sana
   var sum1 = ws[`I${sum}`].w; ///////so'm
   var sumo1 = ws[`I${sumo}`].w; ////so'm o'rtacha
  // var gaz = ws[`I${gaz1}`].w; ////so'm o'rtacha
   /////////// nomi
   var tr11 = ws[`B${tr1}`].w; 
   var ekstra1 = ws[`B${ekstra}`].w;
   var press1 = ws[`B${press}`].w;
   var tr21 = ws[`B${tr2}`].w;
   var raf1 = ws[`B${raf}`].w;
   var gea1 = ws[`B${gea}`].w;
   var qadoq1 = ws[`B${qadoq}`].w;
   //////////// kw 
   var tr11kw = ws[`H${tr1kw}`].w;
   var ekstra1kw = ws[`H${ekstrakw}`].w;
   var press1kw = ws[`H${presskw}`].w;
   var tr21kw = ws[`H${tr2kw}`].w;
   var raf1kw = ws[`H${rafkw}`].w;
   var gea1kw = ws[`H${geakw}`].w;
   var qadoq1kw = ws[`H${qadoqkw}`].w;
   //////////// so'mda
   var tr11sum1 = ws[`I${tr1sum}`].w;
   var ekstra1sum1 = ws[`I${ekstrasum}`].w;
   var press1sum1 = ws[`I${presssum}`].w;
   var tr21sum1 = ws[`I${tr2sum}`].w;
   var raf1sum1 = ws[`I${rafsum}`].w;
   var gea1sum1 = ws[`I${geasum}`].w;
   var qadoq1sum1 = ws[`I${qadoqsum}`].w;
   
   //console.log(uzz)
   //console.log(uz,sum1,sumo1,  tr11, ekstra1, press1, tr21, raf1, gea1, qadoq1);
  //console.log(tr11sum1, ekstra1sum1, press1sum1, tr21sum1, raf1sum1, gea1sum1, qadoq1sum1);
  // console.log(tr11kw, ekstra1kw, press1kw, tr21kw, raf1kw, gea1kw, qadoq1kw)
 
 if (msg.text === uz){
  // console.log(uz)
   bot.sendMessage(msg.chat.id, `
     <b> ${uz}</b> \n Umumiy summa: ${sum1} sum
      \n O'rtacha 1 kv narxi: ${sumo1} sum
      \n ${tr11}: ${tr11sum1} sum
      \n ${ekstra1}: ${ekstra1sum1} sum
      \n ${press1}: ${press1sum1} sum
      \n ${tr21}: ${tr21sum1} sum
      \n ${raf1}: ${raf1sum1} sum
      \n ${gea1}: ${gea1sum1} sum
      \n ${qadoq1}: ${qadoq1sum1} sum `, {parse_mode : "HTML"})
  } else if (msg.text === `${uz}.kv`) {
   // console.log(uz + 'xato')
   bot.sendMessage(msg.chat.id, `
  <b> ${uz}</b>
    \n ${tr11}: ${tr11kw}
    \n ${ekstra1}: ${ekstra1kw}
    \n ${press1}: ${press1kw}
    \n ${tr21}: ${tr21kw}
    \n ${raf1}: ${raf1kw}
    \n ${gea1}: ${gea1kw} 
    \n ${qadoq1}: ${qadoq1kw} `,{parse_mode : "HTML"})
   } 
   i++

  } while (i<1000)
  
  })









