module.exports = {
    home: {
        name:'test',
        data:'12.02.2024'
    },
    hisobot:{

    }
}